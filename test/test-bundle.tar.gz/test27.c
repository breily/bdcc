/*
 * test27 - check multiple assignment
 */

main()
{
  int i, j, k;
  double a, b, c;
  i = j = 3;
  printf ("i is %d, j is %d\n", i, j);
  a = b = 4;
  printf ("a is %f, b is %f\n", a, b);

}

