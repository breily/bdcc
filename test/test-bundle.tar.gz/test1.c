/*
 * test1 - basic test of canonical first program
 */
main()
{
   printf ("hello world\n");
}

