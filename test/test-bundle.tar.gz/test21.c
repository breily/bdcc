/*
 * test21 - check to boolean expressions work
 */
main()
{
   int i, j, k;

   i = 0;
   j = 2;
   k = 3;
   if (k)
      printf ("this should be printed\n");
   if (i)
      printf ("this should NOT be printed\n");
}

