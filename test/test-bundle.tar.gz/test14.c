/*
 * test14 - check to see if op1 works
 */
main()
{
   int i, j, k;
   double a, b, c;

   j = 5;
   i = -j;      /* integer arithmetic */
   printf("i is %d\n", i);
   a = 11;
   b = -a;      /* double arithmetic */
   printf("b is %f\n", b);

   j = 1;
   printf ("j is %d\n", ~j);
}

