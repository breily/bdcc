/*
 * test5 - test function header
 */
main()
{
   int i;
   i = 3;

   printf("i is %d\n", i);
}

