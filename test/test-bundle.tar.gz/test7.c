/*
 * test7 - test call to procedure no args
 */
test7()
{
   printf("in test7\n");
}
main()
{
   test7();
}

