#include <stdio.h>
int in()
{
   return(getchar());
}

