/*
 * test9 - test simple con code
 */
main()
{
   printf("value is %d\n", 1);
}

