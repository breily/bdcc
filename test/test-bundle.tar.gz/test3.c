/*
 * test3 - check for loop
 */
main()
{
   int i;

   i = 0;
   while (i < 5) {
       printf("i is %d\n", i);
       i = i + 1;
   }
}

