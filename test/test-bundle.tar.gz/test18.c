/*
 * test18 - check to see if ! works
 */
main()
{
   int i, j, k;

   i = 3;
   k = 4;
   if (!k < i)
      printf("this should be printed\n");
   else
      printf("this should not be printed\n"); 
}

