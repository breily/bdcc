int a;
int b;
int c;

int main() {
  a = 2;
  b = 6;
  c = a + b;
  printf ("c is %d\n", c);
  return 0;
}

